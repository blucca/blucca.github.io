#!/bin/sh
set -eu
# Setup errors return 2; the final runner preserves its 0/1/2 result.
trap 'code=$?; if [ "$code" -ne 0 ]; then exit 2; fi' 0
cd -- "$(dirname -- "$0")"
ROOT=$(pwd -P)
case "$ROOT" in
  *','* | *':'* | *'
'*) echo 'Extract into a directory whose path uses letters, spaces, numbers, dashes or underscores.' >&2; exit 2 ;;
esac
mkdir -p .cache results
rm -f results/report.json results/junit.xml
N8N_VERSION=${N8N_VERSION:-2.41.7}
case "$N8N_VERSION" in *'
'*) echo 'N8N_VERSION: use a single exact release.' >&2; exit 2 ;; esac
printf '%s\n' "$N8N_VERSION" | grep -Eq '^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-[0-9A-Za-z]+([.-][0-9A-Za-z]+)*)?$' || {
  echo 'N8N_VERSION: choose an exact release, such as 2.41.7.' >&2; exit 2;
}
command -v docker >/dev/null 2>&1 || { echo 'Install and start Docker, then run sh run.sh again.' >&2; exit 2; }
[ -f workflow.json ] && [ -f case.json ] || { echo 'Keep workflow.json and case.json beside run.sh.' >&2; exit 2; }
BASE="ghcr.io/n8n-io/n8n:$N8N_VERSION"
IMAGE="n8n-check-local:0.1.6-$N8N_VERSION"
# Docker obtains the official image on first use. This bootstrap sees only .cache.
# Its Node runtime checks a new download of the fixed runner release on Mac/Linux.
docker run --rm -i --user "$(id -u):$(id -g)" \
  --mount "type=bind,source=$ROOT/.cache,target=/cache" \
  --entrypoint node "$BASE" --input-type=module - <<'NODE'
import { stat, writeFile, rename } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const file = '/cache/runner.tgz';
const expected = '8ac4b07df6fc6eb83726793137e5ad3eb7e97f5bcca243a97cc6c82e6a5ed53d';
const valid = data => createHash('sha256').update(data).digest('hex') === expected;
let cached;
try { cached = (await stat(file)).isFile(); } catch (error) { if (error.code !== 'ENOENT') throw error; }
if (!cached) {
  console.log('Downloading n8n-check v0.1.6...');
  const response = await fetch('https://github.com/blucca/n8n-check/releases/download/v0.1.6/blucca-n8n-check-0.1.6.tgz', { signal: AbortSignal.timeout(120000) });
  if (!response.ok) throw new Error('Runner download HTTP ' + response.status);
  const data = Buffer.from(await response.arrayBuffer());
  if (!valid(data)) throw new Error('Runner SHA256 mismatch; download stopped.');
  await writeFile(file + '.partial', data);
  await rename(file + '.partial', file);
  console.log('Runner download verified.');
} else {
  console.log('Using cached n8n-check v0.1.6.');
}
NODE
cat > .cache/Dockerfile <<'DOCKERFILE'
ARG N8N_VERSION
FROM ghcr.io/n8n-io/n8n:${N8N_VERSION}
USER root
ADD runner.tgz /opt/n8n-check/
USER node
WORKDIR /work
ENTRYPOINT ["node", "/opt/n8n-check/package/bin/n8n-check.mjs"]
DOCKERFILE
# Only the verified archive and generated Dockerfile enter the build context.
printf '*\n!runner.tgz\n!Dockerfile\n' > .cache/.dockerignore
docker build --network none --build-arg "N8N_VERSION=$N8N_VERSION" --tag "$IMAGE" .cache
printf '\nRunning checks with n8n %s; results: %s/results\n' "$N8N_VERSION" "$ROOT"
trap - 0
set +e
docker run --rm --network none --user "$(id -u):$(id -g)" \
  --mount "type=bind,source=$ROOT/workflow.json,target=/inputs/workflow.json,readonly" \
  --mount "type=bind,source=$ROOT/case.json,target=/inputs/case.json,readonly" \
  --mount "type=bind,source=$ROOT/results,target=/results" \
  "$IMAGE" /inputs/workflow.json /inputs/case.json --out /results
CODE=$?
case "$CODE" in 0|1|2) exit "$CODE" ;; *) exit 2 ;; esac
