"""Original, synthetic release-review exercises for SciPy / HiGHS.
Run: python cases.py --output results.json
"""
import argparse
from fractions import Fraction
import json
import platform
import warnings

import highspy
import numpy as np
import scipy
from scipy.optimize import linprog, milp, Bounds, LinearConstraint


def packed(r):
    return dict(status=int(r.status), success=bool(r.success), message=str(r.message),
                x=None if r.x is None else r.x.tolist(),
                fun=None if r.fun is None else float(r.fun))


def run():
    out = {"versions": {"python": platform.python_version(), "scipy": scipy.__version__,
                        "numpy": np.__version__, "highspy": highspy.Highs().version()},
           "cases": []}
    # 1. API defaults are model semantics, not merely solver settings.
    wrong = linprog([1.], A_eq=[[1.]], b_eq=[-1.], method="highs")
    right = linprog([1.], A_eq=[[1.]], b_eq=[-1.], bounds=[(None, None)], method="highs")
    assert wrong.status == 2 and right.success and abs(right.x[0]+1) < 1e-10
    out["cases"].append({"id": "default-bounds", "wrong": packed(wrong), "correct": packed(right)})
    # 2. The selected method changes whether an integrality request is honored.
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        wrong = linprog([1.], A_ub=[[-1.]], b_ub=[-.5], bounds=[(0, 2)],
                        integrality=[1], method="highs-ds")
    right = linprog([1.], A_ub=[[-1.]], b_ub=[-.5], bounds=[(0, 2)],
                    integrality=[1], method="highs")
    assert wrong.success and abs(wrong.x[0]-.5) < 1e-10
    assert right.success and abs(right.x[0]-1) < 1e-10
    out["cases"].append({"id": "method-integrality", "wrong": packed(wrong), "correct": packed(right),
                         "warnings": [str(z.message) for z in w]})
    # 3. A minimizing API uses a negated objective for maximizing business value.
    value = np.array([5., 3.])
    r = linprog(-value, A_ub=[[1., 1.]], b_ub=[4.], method="highs")
    reported = float(value @ r.x)
    assert r.success and abs(r.fun+20) < 1e-10 and abs(reported-20) < 1e-10
    out["cases"].append({"id": "objective-sense", "solver": packed(r), "business_value": reported})
    # 4. Rounding an LP is not a MIP algorithm. Ties round to even in NumPy.
    lp = linprog([1., 1.], A_ub=[[-1., -1.]], b_ub=[-1.5], bounds=[(0,1),(0,1)], method="highs")
    rounded = np.rint(lp.x)
    mip = milp([1.,1.], integrality=[1,1], bounds=Bounds([0,0],[1,1]),
               constraints=LinearConstraint([[1.,1.]], [1.5], [np.inf]))
    assert lp.success and float(rounded.sum()) < 1.5 and mip.success and abs(mip.fun-2) < 1e-10
    out["cases"].append({"id": "rounding", "relaxation": packed(lp), "rounded": rounded.tolist(),
                         "rounded_row_shortfall": float(1.5-rounded.sum()), "correct": packed(mip)})
    # 5. A correct solve of yesterday's model cannot verify today's requirement.
    r = linprog([2.,3.], A_ub=[[-1.,-1.]], b_ub=[-4.], method="highs")
    release_demand = 6.
    shortfall = float(max(0., release_demand-r.x.sum()))
    assert r.success and abs(shortfall-2) < 1e-10
    out["cases"].append({"id": "stale-input", "solver": packed(r), "solved_demand":4.,
                         "release_demand": release_demand, "independent_shortfall": shortfall})
    # 6. Deterministic native node-budget stop with a supplied feasible incumbent.
    h = highspy.Highs()
    for k,v in [("output_flag",False),("presolve","off"),("mip_max_nodes",0)]:
        assert h.setOptionValue(k,v) == highspy.HighsStatus.kOk
    h.addVars(3,np.zeros(3),np.ones(3))
    idx=np.arange(3,dtype=np.int32)
    h.changeColsCost(3,idx,np.array([8.,5.,4.]))
    h.changeColsIntegrality(3,idx,np.ones(3,dtype=np.uint8))
    h.addRow(3.5,highspy.kHighsInf,3,idx,np.array([4.,3.,2.]))
    assert h.setSolution(3,idx,np.ones(3)) == highspy.HighsStatus.kOk
    h.run()
    info,sol=h.getInfo(),h.getSolution()
    x=np.array(sol.col_value)
    status=h.modelStatusToString(h.getModelStatus())
    assert sol.value_valid and 4*x[0]+3*x[1]+2*x[2] >= 3.5-1e-7
    assert np.all(x >= -1e-7) and np.all(x <= 1+1e-7)
    assert np.max(np.abs(x-np.rint(x))) <= 1e-7
    assert abs(np.array([8.,5.,4.]) @ x - info.objective_function_value) <= 1e-7
    assert h.getModelStatus() != highspy.HighsModelStatus.kOptimal
    def finite(v): return float(v) if np.isfinite(v) else str(float(v))
    out["cases"].append({"id": "limited-incumbent", "model_status": status,
                         "primal_status":int(info.primal_solution_status), "x":x.tolist(),
                         "objective":finite(info.objective_function_value),
                         "dual_bound":finite(info.mip_dual_bound), "relative_gap":finite(info.mip_gap),
                         "release_class":"feasible_incumbent_not_proven_optimal"})
    # 7. A tiny certificate can be verified independently with exact fractions.
    x=Fraction(1,2); y=Fraction(1,2)
    assert 2*x == 1 and 2*y == 1 and x == y and x >= 0
    out["cases"].append({"id":"rational-certificate", "primal_x":str(x), "dual_y":str(y),
                         "primal_objective":str(x),"dual_objective":str(y),"exact_gap":"0"})
    out["passed"]=len(out["cases"])
    return out

if __name__ == "__main__":
    p=argparse.ArgumentParser();p.add_argument("--output",default="results.json");a=p.parse_args()
    result=run()
    with open(a.output,"w") as f:json.dump(result,f,indent=2,allow_nan=False);f.write("\n")
    print(json.dumps(result,indent=2,allow_nan=False))
