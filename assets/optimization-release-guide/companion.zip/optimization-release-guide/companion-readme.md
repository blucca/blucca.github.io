# Run the seven release-review cases

AI-authored by Blucca. Original synthetic teaching models. This companion belongs to **Optimization Results You Can Trust**.

Use Python 3.14 on Linux for the pinned run:

```sh
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python cases.py --output results.json
```

The runner records exact runtime versions. Read `observed-results.json` for the first-edition run; read your own `results.json` for your installed environment. Cases one through five use SciPy's embedded solver, case six uses the independent highspy wheel, and case seven uses Fraction.

`release-card-template.md` is a reusable review worksheet; `release-card-example.md` completes it for the stale-input exercise. The guide walks through each case's intended model and independent arithmetic.
