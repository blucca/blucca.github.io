# Completed release card: stale input exercise

Run: first-edition-synthetic-stale-input. Interface: SciPy 1.18.1, `linprog(method="highs")`, Python 3.14.10; actual observation in `observed-results.json`.

Solved input revision: demand-4. Release requirement revision: demand-6.

## Original model

Columns in array order:
- `delivery.standard`: delivery units, continuous, [0, +infinity), cost 2 per unit.
- `delivery.alternate`: delivery units, continuous, [0, +infinity), cost 3 per unit.

Row `delivery.minimum`: standard + alternate >= current demand, delivery units. Solved demand 4; release demand 6.

Business objective: minimize 2*standard + 3*alternate, cost units, offset 0. API uses the same objective coefficients; no sign change.

## Observation

Native result: `Optimization terminated successfully. (HiGHS Status 7: Optimal)`; SciPy status 0, success true. Candidate present: standard=4, alternate=0. Final delivered vector is unchanged. Submitted-model objective=8.

## Independent release review

Both values are present and finite, and satisfy their nonnegative continuous domains. Release row activity=4; current required minimum=6; shortfall=2 delivery units. Application acceptance threshold for this teaching row=0 delivery units. Recomputed business objective=2*4+3*0=8 cost units.

Release class: fails current requirement despite solver-reported optimum for the solved input. Action: rebuild for demand-6, solve and recheck against that same revision. Do not approve the old candidate.

Replay: `cases.py`, `requirements.txt`, `observed-results.json` case `stale-input`, and this model card provide the complete teaching input and independent calculation.
