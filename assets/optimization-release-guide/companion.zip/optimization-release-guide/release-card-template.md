# Optimization release card

## Model identity

- Run ID:
- Solved input revision:
- Release requirement revision:
- Interface and runtime version:
- Selected method and options:

## Original model

- Columns, ordered: ID / unit / lower bound / upper bound / domain
- Rows, ordered: ID / unit / coefficients by column ID / lower and upper limits
- Business objective: sense / coefficients / unit / constant offset
- API objective transformation:

## Candidate and termination

- Raw candidate, by column ID:
- Final delivered candidate, by column ID:
- Postprocessing between raw and delivered values:
- Native termination status:
- Candidate availability and primal status:
- Objective / lower or upper bound / reported gap:

## Original-unit review

- Required values present and finite:
- Bounds and domain distances, by column ID:
- Row activity and violations, by row ID:
- Declared application-level acceptance thresholds, with units:
- Recomputed business objective on final candidate:
- Release class:
- Release action:

## Replay files

- Source and requirements:
- Original input and named mappings:
- Raw run result:
- Delivered decision:
- Independent check calculation:
