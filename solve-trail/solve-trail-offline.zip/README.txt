Open SolveTrail.html in a browser. Logs stay on this device.
Save/restore a private comparison JSON to continue with your own material.
The editable brief omits raw logs and file names by default.
Source: https://github.com/blucca/blucca.github.io/tree/main/solve-trail
